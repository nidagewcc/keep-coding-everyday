//var ctx = document.getElementById("myChart").getContext("2d");
//var myNewChart = new Chart(ctx).PolarArea(data);

//var app = new Vue({
//    el:'#app',
//    data:{
//
//
//    },
//    methods:{
//
//        show:function(){
//            this.$http.get('/data-collect/refresh').then(
//                function(ret){
//                    var data = ret.body;
//
//                    console.log(data);
//                }
//            )
//        }
//
//    },
//    mounted: function () {
//        this.show();
//    }
//
//})